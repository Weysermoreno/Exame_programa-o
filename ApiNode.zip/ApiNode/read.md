1ª Baixar o projeto.
2ª Executa o comando "npm  install " na pasta do projeto para instalar as dependenciais do sistema.
3ª Deve Criar um banco no seu servidor mysql com o nome "accounts".
4ª E executa o comando " npx knex migrate:latest " para executar as migração para criar as tabelas no banco de dados.
5ª Executa o comando "npm run dev" para rodar o sistema.