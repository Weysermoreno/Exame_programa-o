const express = require('express');
const knex = require('knex');
require('dotenv').config();
const knexConfig = require('./knexfile'); 
const db = knex(knexConfig.development);
const handlebar = require('express-handlebars');

const app = express();
app.use(express.json());
app.engine('handlebars', handlebar.engine());
app.set('view engine', 'handlebars');
app.use(express.urlencoded({ extended: false }));

// Rota para criar um novo usuário
app.post('/users', async (req, res) => {
  try {
    const { username, email, password } = req.body;
     const getUser = await db('users').insert({ username, email, password });
    res.status(200).render("infoSms",{
            layout:false,
            sms:"Usuario criado com successo",
            status:true
        })
 
  } catch (error) {
    res.status(500).render("infoSms",{
        layout:false,
        sms:"Usuario já existe",
        status:false
    })
  }
});

// Rota para listar todos os usuários
app.get('/users', async (req, res) => {
  try {
    const data = await db('users').select('*');

    res.render("allUser",{
        layout:false,
        users:data
        }
    );
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/', async (req, res) => {
   res.render("create",{
    layout:false,
   })
  });

// Rota para buscar um usuário pelo ID
app.get('/users/edit/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const user = await db('users').where({ id }).first();
    if (!user) {
      res.status(404).render("infoSms",{
        layout:false,
        sms:"Usuario não encontrado!",
        status:true
    })
    } else {
      res.render("edit",{
        layout:false,
        user,
    })
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
// Rota para atualizar um usuário pelo ID

app.post('/users/update', async (req, res) => {
  try {
    const { username, email, password,id } = req.body;
    const updatedUser = await db('users').where({ id }).update({ username, email, password });
    res.render("infoSms",{
      layout:false,
      sms:"Usuario editado com sucesso !",
      status:true
  })
  } catch (error) {
    res.status(500).render("infoSms",{
      layout:false,
      sms:"Não foi possivél editar o usúario !",
  })
  }
});

// Rota para deletar um usuário pelo ID
app.get('/users/delete/:id', async (req, res) => {
  try {
    const { id } = req.params;
     await db('users').where({ id }).del();
    res.status(200).render("infoSms",{
      layout:false,
      sms:"Usuario deletado com sucesso !",
      status:true
  })
  } catch (error) {
    res.status(500).render("infoSms",{
      layout:false,
      sms:"não foi possivél realizar a operação!",
      status:true
  })
}
}
);

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
